# Finance
Statement of Purpose for joining Finance - CEV
